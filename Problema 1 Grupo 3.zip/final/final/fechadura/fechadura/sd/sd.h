#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include <string.h>
#include <stdio.h>

// Defini??es de pinos SPI
#define CS_PIN PC6
#define MOSI_PIN PB3
#define MISO_PIN PB4
#define SCK_PIN PB5

// Comandos do cart?o SD
#define CMD0  0x40  // Reset
#define CMD1  0x41  // Inicializa??o
#define CMD16 0x50  // Define o tamanho do bloco
#define CMD24 0x58  // Escreve um bloco
//vari?veis utilizadas
uint8_t sd_inicializado = 0;
//usu?rio e hora para serem salvos
uint8_t HORA[512] = {0}; uint16_t USUARIO = 0;

// Fun??es SPI
void SPI_Init(void) {
	DDRB |= (1 << CS_PIN) | (1 << MOSI_PIN) | (1 << SCK_PIN); // Configura MOSI, SCK, CS como sa?da
	DDRB &= ~(1 << MISO_PIN);                                 // Configura MISO como entrada
	SPCR = (1 << SPE) | (1 << MSTR) | (1 << SPR0);            // Habilita SPI, modo mestre, clock f/16
	PORTB |= (1 << CS_PIN);                                   // CS desativado
}

uint8_t SPI_Transfer(uint8_t data) {
	SPDR = data;                           // Envia dado
	while (!(SPSR & (1 << SPIF)));         // Aguarda transmiss?o
	return SPDR;                           // Retorna dado recebido
}

// Controle do CS
void SD_Select(void) {
	PORTB &= ~(1 << CS_PIN);
}

void SD_Deselect(void) {
	PORTB |= (1 << CS_PIN);
}

// Envia comando ao cart?o SD
uint8_t SD_SendCommand(uint8_t cmd, uint32_t arg, uint8_t crc) {
	SD_Select();
	SPI_Transfer(cmd | 0x40);               // Envia comando
	SPI_Transfer(arg >> 24);                // Argumento (MSB)
	SPI_Transfer(arg >> 16);
	SPI_Transfer(arg >> 8);
	SPI_Transfer(arg);                      // Argumento (LSB)
	SPI_Transfer(crc);                      // CRC

	// Aguarda resposta
	for (uint8_t i = 0; i < 8; i++) {
		uint8_t response = SPI_Transfer(0xFF);
		if (response != 0xFF) {
			return response;
		}
	}
	return 0xFF; // Sem resposta
}

// Inicializa o cart?o SD
uint8_t SD_Init(void) {
	SD_Deselect();
	for (uint8_t i = 0; i < 10; i++) {
		SPI_Transfer(0xFF); // Envia clocks para inicializar
	}
	SD_Select();
	
	// Envia CMD0 para resetar
	if (SD_SendCommand(CMD0, 0, 0x95) != 0x01) {
		UART_SendString("Erro: Falha no CMD0\r");
		return 1; // Erro
	}
	UART_SendString("CMD0 enviado com sucesso\r");
	
	// Envia CMD1 para inicializar
	while (SD_SendCommand(CMD1, 0, 0xFF) != 0x00);
	UART_SendString("CMD1 enviado com sucesso\r");
	
	// Define tamanho do bloco como 512 bytes
	if (SD_SendCommand(CMD16, 512, 0xFF) != 0x00) {
		UART_SendString("Erro: Falha no CMD16\r");
		return 1; // Erro
	}
	UART_SendString("Tamanho do bloco definido para 512 bytes\r");
	
	SD_Deselect();
	SPI_Transfer(0xFF);
	
	return 0; // Sucesso
}

// Escreve um bloco de 512 bytes no cart?o SD
uint8_t SD_WriteBlock(uint32_t block, const uint8_t *data) {
	if (SD_SendCommand(CMD24, block * 512, 0xFF) != 0x00) {
		UART_SendString("Erro: Falha no CMD24\r");
		return 1; // Erro
	}
	SPI_Transfer(0xFE); // In?cio do token de dados
	
	// Envia 512 bytes de dados
	for (uint16_t i = 0; i < 512; i++) {
		SPI_Transfer(data[i]);
	}
	
	// Envia CRC (2 bytes fict?cios)
	SPI_Transfer(0xFF);
	SPI_Transfer(0xFF);
	
	// Verifica resposta
	uint8_t response = SPI_Transfer(0xFF);
	if ((response & 0x1F) != 0x05) {
		UART_SendString("Erro: Falha ao escrever bloco\r");
		return 2; // Erro
	}
	UART_SendString("Bloco escrito com sucesso\r");
	
	// Aguarda at? o cart?o estar pronto
	while (SPI_Transfer(0xFF) == 0x00);
	
	SD_Deselect();
	SPI_Transfer(0xFF);
	return 0; // Sucesso
}

// Escreve dados no formato solicitado
void EscreverDados(const char *hora, const char *usuario, uint8_t *HORA, uint16_t *USUARIO) {
	char linha[32];
	snprintf(linha, sizeof(linha), "%s - %s\n", hora, usuario);

	uint16_t len = strlen(linha);
	if (*USUARIO + len > 4096) {
		UART_SendString("Erro: Buffer cheio\r");
		return;
	}

	memcpy(HORA + *USUARIO, linha, len);
	*USUARIO += len;
	if (SD_WriteBlock(0, USUARIO) == 0) {
		UART_SendString("Dados escritos no bloco 0\r");
		} else {
		UART_SendString("Erro ao escrever dados\r");
	}
}

void TestaInicializacao(){
	if (!sd_inicializado) {
		if (SD_Init() == 0) {
			UART_SendString("Cart?o SD inicializado com sucesso\r");
			sd_inicializado = 1;
			} else {
			UART_SendString("Erro ao inicializar cart?o SD\r");
			return 1;
		}
	}
}