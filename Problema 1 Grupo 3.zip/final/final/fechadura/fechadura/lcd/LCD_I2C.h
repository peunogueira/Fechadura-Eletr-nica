/*
 * lcd_i2c.c
 *
 * Created: 04/09/2017 07:37:47 p. m.
 * Author : falco
 */

#include <avr/io.h>
#include <avr/pgmspace.h> // Include this header for pgm_read_byte

// Define o pin 0x02 como En da LCD
// e o pin 0x01 como RS da LCD
// Os pinos de dados mais altos do m�dulo s�o conectados aos pinos da LCD: P4-D4, P5-D5, P6-D6, P7-D7
// O pino R/W � conectado ao terra

// ----- Prot�tipos de Fun��es ----- //
void lcd_init();            // Fun��o para inicializar a LCD
void toggle();              // Fun��o de latch para a LCD
void lcd_cmd_hf(char v1);   // Fun��o para enviar comando de meio byte para a LCD
void lcd_cmd(char v2);      // Fun��o para enviar comando para a LCD
void lcd_dwr(char v3);      // Fun��o para enviar dados para a LCD
void lcd_msg(char *c);      // Fun��o para enviar string para a LCD
void delay(int ms);         // Fun��o de delay
void lcd_lef_sh();          // Fun��o para deslocamento � esquerda
void lcd_rig_sh();          // Fun��o para deslocamento � direita
// --------------------------------------- //

void toggle()
{
    TWDR |= 0x02;                    // PIN En da LCD (Enable = 1); Latching data na LCD (High to Low signal)
    TWCR = (1<<TWINT) | (1<<TWEN);   // Habilitar I2C e limpar interrup��o
    while (!(TWCR & (1<<TWINT)));    // Aguarda a transmiss�o
    delay(1);
    TWDR &= ~0x02;                   // PIN Enable da LCD (Enable = 0);
    TWCR = (1<<TWINT) | (1<<TWEN);   // Habilitar I2C e limpar interrup��o
    while (!(TWCR & (1<<TWINT)));
}

void lcd_cmd_hf(char v1)
{
    TWDR &= ~0x01;                   // RS = 0; Seleciona o registrador de comando
    TWCR = (1<<TWINT) | (1<<TWEN);   // Habilitar I2C e limpar interrup��o
    while (!(TWCR & (1<<TWINT)));
    TWDR &= 0x0F;                    // Limpar os 4 bits mais altos
    TWCR = (1<<TWINT) | (1<<TWEN);   // Habilitar I2C e limpar interrup��o
    while (!(TWCR & (1<<TWINT)));
    TWDR |= (v1 & 0xF0);             // Enviar os 4 bits mais altos para a LCD
    TWCR = (1<<TWINT) | (1<<TWEN);   // Habilitar I2C e limpar interrup��o
    while (!(TWCR & (1<<TWINT)));
    toggle();
}

void lcd_cmd(char v2)
{
    TWDR &= ~0x01;                   // RS = 0; Seleciona o registrador de comando
    TWCR = (1<<TWINT) | (1<<TWEN);   // Habilitar I2C e limpar interrup��o
    while (!(TWCR & (1<<TWINT)));
    TWDR &= 0x0F;                    // Limpar os 4 bits mais altos
    TWCR = (1<<TWINT) | (1<<TWEN);   // Habilitar I2C e limpar interrup��o
    while (!(TWCR & (1<<TWINT)));
    TWDR |= (v2 & 0xF0);             // Enviar os 4 bits mais altos para a LCD
    TWCR = (1<<TWINT) | (1<<TWEN);   // Habilitar I2C e limpar interrup��o
    while (!(TWCR & (1<<TWINT)));
    toggle();

    TWDR &= 0x0F;                    // Limpar os 4 bits mais altos
    TWCR = (1<<TWINT) | (1<<TWEN);   // Habilitar I2C e limpar interrup��o
    while (!(TWCR & (1<<TWINT)));
    TWDR |= ((v2 & 0x0F)<<4);        // Enviar os 4 bits mais baixos para a LCD
    TWCR = (1<<TWINT) | (1<<TWEN);   // Habilitar I2C e limpar interrup��o
    while (!(TWCR & (1<<TWINT)));
    toggle();
}

void lcd_dwr(char v3)
{
    TWDR |= 0x01;                    // RS = 1; Seleciona o registrador de dados
    TWCR = (1<<TWINT) | (1<<TWEN);   // Habilitar I2C e limpar interrup��o
    while (!(TWCR & (1<<TWINT)));
    TWDR &= 0x0F;                    // Limpar os 4 bits mais altos
    TWCR = (1<<TWINT) | (1<<TWEN);   // Habilitar I2C e limpar interrup��o
    while (!(TWCR & (1<<TWINT)));
    TWDR |= (v3 & 0xF0);             // Enviar os 4 bits mais altos para a LCD
    TWCR = (1<<TWINT) | (1<<TWEN);   // Habilitar I2C e limpar interrup��o
    while (!(TWCR & (1<<TWINT)));
    toggle();

    TWDR &= 0x0F;                    // Limpar os 4 bits mais altos
    TWCR = (1<<TWINT) | (1<<TWEN);   // Habilitar I2C e limpar interrup��o
    while (!(TWCR & (1<<TWINT)));
    TWDR |= ((v3 & 0x0F)<<4);        // Enviar os 4 bits mais baixos para a LCD
    TWCR = (1<<TWINT) | (1<<TWEN);   // Habilitar I2C e limpar interrup��o
    while (!(TWCR & (1<<TWINT)));
    toggle();
}

void lcd_init()
{
    lcd_cmd_hf(0x30);       // Sequ�ncia de inicializa��o da LCD
    lcd_cmd_hf(0x30);
    lcd_cmd_hf(0x20);
    lcd_cmd(0x28);          // Seleciona LCD 16x2 em modo 4 bits
    lcd_cmd(0x0C);          // Display ON, cursor OFF
    lcd_cmd(0x01);          // Limpar display
    lcd_cmd(0x06);          // Incremento autom�tico do cursor
    lcd_cmd(0x80);          // Primeira linha, primeira posi��o
}

void delay(int ms)
{
    int i, j;
    for (i = 0; i <= ms; i++)
        for (j = 0; j <= 120; j++);
}

void lcd_msg(char *c)
{
    while (*c != 0)         // Aguarda at� que todos os caracteres sejam enviados
        lcd_dwr(*c++);      // Enviar caractere para a LCD
}

void lcd_msg_P(const char *c)
{
    while (pgm_read_byte(c) != 0)
    {
        lcd_dwr(pgm_read_byte(c++)); // Ler caractere por caractere da mem�ria Flash
    }
}

void lcd_rig_sh()
{
    lcd_cmd(0x1C);          // Comando para deslocamento � direita
    delay(400);
}

void lcd_lef_sh()
{
    lcd_cmd(0x18);          // Comando para deslocamento � esquerda
    delay(200);
}
