#include <avr/io.h>
#include <util/delay.h>

// Inicializa UART
void UART_Init(unsigned int ubrr) {
    UBRR0H = (unsigned char)(ubrr >> 8);  // Define parte alta do divisor
    UBRR0L = (unsigned char)ubrr;         // Define parte baixa do divisor
    UCSR0B = (1 << TXEN0);                // Habilita transmiss�o UART
    UCSR0C = (1 << UCSZ01) | (1 << UCSZ00); // Configura 8 bits de dados
}

// Transmite um byte pela UART
void UART_Transmit(unsigned char data) {
    while (!(UCSR0A & (1 << UDRE0)));     // Aguarda buffer estar livre
    UDR0 = data;                          // Envia o dado
}

// Envia uma string pela UART com nome de usu�rio e hora
void UART_SendString(const char *usuario, const char *hora) {
    UART_Transmit('U');  // Envia 'U' para "Usuario"
    UART_Transmit('s');
    UART_Transmit('u');
    UART_Transmit('a');
    UART_Transmit('r');
    UART_Transmit('i');
    UART_Transmit('o');
    UART_Transmit(':');

    // Envia os caracteres do nome do usuario
    while (*usuario) {
        UART_Transmit(*usuario++);
    }

    UART_Transmit('  -  ');  // Envia o tra�o entre usu�rio e hora

    UART_Transmit('H');  // Envia 'H' para "Hora"
    UART_Transmit('o');
    UART_Transmit('r');
    UART_Transmit('a');
    UART_Transmit(':');

    // Envia os caracteres da hora
    while (*hora) {
        UART_Transmit(*hora++);
    }

    UART_Transmit('\r');  // Quebra de linha ao final
}
