#define F_CPU 8000000UL
#include <avr/io.h>
#include <util/delay.h>
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdbool.h>

#define SCL_CLK 100000L
#define BITRATE(TWSR)	((F_CPU/SCL_CLK)-16)/(2*pow(4,(TWSR&((1<<TWPS0)|(1<<TWPS1)))))

#define Device_Write_address	0xD0
#define Device_Read_address		0xD1
#define TimeFormat12			0x40
#define AMPM					0x20

int second, minute, hour, day, date, month, year;
char HORA_DS[20];

void I2C_Init()
{
	TWBR = BITRATE(TWSR = 0x00);
}

uint8_t I2C_Start(char write_address)
{
	uint8_t status;
	TWCR = (1<<TWSTA)|(1<<TWEN)|(1<<TWINT);
	while (!(TWCR & (1<<TWINT)));
	status = TWSR & 0xF8;
	if (status != 0x08)
	return 0;
	TWDR = write_address;
	TWCR = (1<<TWEN)|(1<<TWINT);
	while (!(TWCR & (1<<TWINT)));
	status = TWSR & 0xF8;
	if (status == 0x18)
	return 1;
	if (status == 0x20)
	return 2;
	else
	return 3;
}

uint8_t I2C_Repeated_Start(char read_address)
{
	uint8_t status;
	TWCR = (1<<TWSTA)|(1<<TWEN)|(1<<TWINT);
	while (!(TWCR & (1<<TWINT)));
	status = TWSR & 0xF8;
	if (status != 0x10)
	return 0;
	TWDR = read_address;
	TWCR = (1<<TWEN)|(1<<TWINT);
	while (!(TWCR & (1<<TWINT)));
	status = TWSR & 0xF8;
	if (status == 0x40)
	return 1;
	if (status == 0x20)
	return 2;
	else
	return 3;
}

void I2C_Stop()
{
	TWCR=(1<<TWSTO)|(1<<TWINT)|(1<<TWEN);
	while(TWCR & (1<<TWSTO));
}

uint8_t I2C_Write(char data)
{
	uint8_t status;
	TWDR = data;
	TWCR = (1<<TWEN)|(1<<TWINT);
	while (!(TWCR & (1<<TWINT)));
	status = TWSR & 0xF8;
	if (status == 0x28)
	return 0;
	if (status == 0x30)
	return 1;
	else
	return 2;
}

int I2C_Read_Ack()
{
	TWCR=(1<<TWEN)|(1<<TWINT)|(1<<TWEA);
	while (!(TWCR & (1<<TWINT)));
	return TWDR;
}

int I2C_Read_Nack()
{
	TWCR=(1<<TWEN)|(1<<TWINT);
	while (!(TWCR & (1<<TWINT)));
	return TWDR;
}

bool IsItPM(char hour_)
{
	if(hour_ & (AMPM))
	return true;
	else
	return false;
}

// Fun��o para converter BCD para decimal
uint8_t BCD_To_Decimal(uint8_t bcd)
{
    return ((bcd >> 4) * 10) + (bcd & 0x0F);
}

void RTC_Read_Clock()
{
    I2C_Start(Device_Write_address);
    I2C_Write(0x00);  // Endere�o do registro de hora
    I2C_Repeated_Start(Device_Read_address);
    second = I2C_Read_Ack();    // L� o segundo
    minute = I2C_Read_Ack();    // L� o minuto
    hour = I2C_Read_Nack();     // L� a hora

    // Converte de BCD para decimal
    second = BCD_To_Decimal(second);
    minute = BCD_To_Decimal(minute);
    hour = BCD_To_Decimal(hour);

    // Se a hora estiver em formato 12 horas, ajusta para 24 horas
    if (hour & TimeFormat12) {
        if (hour & AMPM) {  // Se PM, adiciona 12
            hour = (hour & 0x1F) + 12; 
        } else {
            hour &= 0x1F;  // Se AM, mantemos a hora original
        }
    }

    // Exibe a hora no formato 24 horas
    sprintf(HORA_DS, "%02d:%02d:%02d", hour, minute, second);
    I2C_Stop();
    _delay_ms(10);
}
